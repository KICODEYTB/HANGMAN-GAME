﻿namespace HangmanGame
{
    partial class frm_ZoneJeu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_ZoneJeu));
            this.btnRetour = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.table = new System.Windows.Forms.TableLayoutPanel();
            this.button37 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.picImagePendu = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.point = new System.Windows.Forms.Label();
            this.lblPoint = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.panel = new System.Windows.Forms.Panel();
            this.lblGames = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblIndice = new System.Windows.Forms.Label();
            this.nomIndice = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.btnRetour)).BeginInit();
            this.panel2.SuspendLayout();
            this.table.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picImagePendu)).BeginInit();
            this.panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRetour
            // 
            this.btnRetour.BackgroundImage = global::HangmanGame.Properties.Resources.retour;
            this.btnRetour.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRetour.Location = new System.Drawing.Point(415, 226);
            this.btnRetour.Margin = new System.Windows.Forms.Padding(410, 220, 0, 0);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(45, 43);
            this.btnRetour.TabIndex = 6;
            this.btnRetour.TabStop = false;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.Controls.Add(this.table);
            this.panel2.Controls.Add(this.btnRetour);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 405);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(469, 278);
            this.panel2.TabIndex = 1;
            // 
            // table
            // 
            this.table.ColumnCount = 9;
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.table.Controls.Add(this.button37, 8, 2);
            this.table.Controls.Add(this.button36, 7, 2);
            this.table.Controls.Add(this.button35, 6, 2);
            this.table.Controls.Add(this.button34, 5, 2);
            this.table.Controls.Add(this.button33, 4, 2);
            this.table.Controls.Add(this.button32, 3, 2);
            this.table.Controls.Add(this.button31, 2, 2);
            this.table.Controls.Add(this.button30, 1, 2);
            this.table.Controls.Add(this.button29, 0, 2);
            this.table.Controls.Add(this.button28, 8, 1);
            this.table.Controls.Add(this.button26, 0, 3);
            this.table.Controls.Add(this.button25, 0, 3);
            this.table.Controls.Add(this.button24, 0, 3);
            this.table.Controls.Add(this.button23, 0, 3);
            this.table.Controls.Add(this.button22, 0, 3);
            this.table.Controls.Add(this.button21, 0, 3);
            this.table.Controls.Add(this.button20, 0, 3);
            this.table.Controls.Add(this.button19, 0, 3);
            this.table.Controls.Add(this.button18, 0, 3);
            this.table.Controls.Add(this.button17, 7, 1);
            this.table.Controls.Add(this.button16, 6, 1);
            this.table.Controls.Add(this.button15, 5, 1);
            this.table.Controls.Add(this.button14, 4, 1);
            this.table.Controls.Add(this.button13, 3, 1);
            this.table.Controls.Add(this.button12, 2, 1);
            this.table.Controls.Add(this.button11, 1, 1);
            this.table.Controls.Add(this.button10, 0, 1);
            this.table.Controls.Add(this.button9, 8, 0);
            this.table.Controls.Add(this.button8, 7, 0);
            this.table.Controls.Add(this.button7, 6, 0);
            this.table.Controls.Add(this.button6, 5, 0);
            this.table.Controls.Add(this.button5, 4, 0);
            this.table.Controls.Add(this.button4, 3, 0);
            this.table.Controls.Add(this.button3, 2, 0);
            this.table.Controls.Add(this.button2, 0, 0);
            this.table.Controls.Add(this.button1, 1, 0);
            this.table.Location = new System.Drawing.Point(26, 29);
            this.table.Name = "table";
            this.table.RowCount = 4;
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.table.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.table.Size = new System.Drawing.Size(401, 183);
            this.table.TabIndex = 7;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.White;
            this.button37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button37.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.ForeColor = System.Drawing.Color.DimGray;
            this.button37.Location = new System.Drawing.Point(354, 93);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(44, 39);
            this.button37.TabIndex = 42;
            this.button37.Tag = "0";
            this.button37.Text = "0";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.White;
            this.button36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button36.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.ForeColor = System.Drawing.Color.DimGray;
            this.button36.Location = new System.Drawing.Point(311, 93);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(37, 39);
            this.button36.TabIndex = 41;
            this.button36.Tag = "Z";
            this.button36.Text = "Z";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.White;
            this.button35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button35.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.ForeColor = System.Drawing.Color.DimGray;
            this.button35.Location = new System.Drawing.Point(268, 93);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(37, 39);
            this.button35.TabIndex = 40;
            this.button35.Tag = "Y";
            this.button35.Text = "Y";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.White;
            this.button34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button34.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.ForeColor = System.Drawing.Color.DimGray;
            this.button34.Location = new System.Drawing.Point(225, 93);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(37, 39);
            this.button34.TabIndex = 39;
            this.button34.Tag = "X";
            this.button34.Text = "X";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.White;
            this.button33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button33.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.ForeColor = System.Drawing.Color.DimGray;
            this.button33.Location = new System.Drawing.Point(182, 93);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(37, 39);
            this.button33.TabIndex = 38;
            this.button33.Tag = "W";
            this.button33.Text = "W";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.White;
            this.button32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button32.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.ForeColor = System.Drawing.Color.DimGray;
            this.button32.Location = new System.Drawing.Point(139, 93);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(37, 39);
            this.button32.TabIndex = 37;
            this.button32.Tag = "V";
            this.button32.Text = "V";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.White;
            this.button31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button31.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.ForeColor = System.Drawing.Color.DimGray;
            this.button31.Location = new System.Drawing.Point(96, 93);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(37, 39);
            this.button31.TabIndex = 36;
            this.button31.Tag = "U";
            this.button31.Text = "U";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.White;
            this.button30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button30.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.Color.DimGray;
            this.button30.Location = new System.Drawing.Point(53, 93);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(37, 39);
            this.button30.TabIndex = 35;
            this.button30.Tag = "T";
            this.button30.Text = "T";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.White;
            this.button29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button29.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.ForeColor = System.Drawing.Color.DimGray;
            this.button29.Location = new System.Drawing.Point(3, 93);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(44, 39);
            this.button29.TabIndex = 34;
            this.button29.Tag = "S";
            this.button29.Text = "S";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.White;
            this.button28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button28.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.ForeColor = System.Drawing.Color.DimGray;
            this.button28.Location = new System.Drawing.Point(354, 48);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(44, 39);
            this.button28.TabIndex = 7;
            this.button28.Tag = "R";
            this.button28.Text = "R";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.White;
            this.button26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button26.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.Color.DimGray;
            this.button26.Location = new System.Drawing.Point(139, 138);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(37, 42);
            this.button26.TabIndex = 33;
            this.button26.Tag = "4";
            this.button26.Text = "4";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.White;
            this.button25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button25.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.Color.DimGray;
            this.button25.Location = new System.Drawing.Point(3, 138);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(44, 42);
            this.button25.TabIndex = 32;
            this.button25.Tag = "1";
            this.button25.Text = "1";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.White;
            this.button24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button24.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.DimGray;
            this.button24.Location = new System.Drawing.Point(53, 138);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(37, 42);
            this.button24.TabIndex = 31;
            this.button24.Tag = "2";
            this.button24.Text = "2";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.White;
            this.button23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button23.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.DimGray;
            this.button23.Location = new System.Drawing.Point(182, 138);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(37, 42);
            this.button23.TabIndex = 30;
            this.button23.Tag = "5";
            this.button23.Text = "5";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.White;
            this.button22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button22.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.DimGray;
            this.button22.Location = new System.Drawing.Point(311, 138);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(37, 42);
            this.button22.TabIndex = 29;
            this.button22.Tag = "8";
            this.button22.Text = "8";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.White;
            this.button21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button21.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.DimGray;
            this.button21.Location = new System.Drawing.Point(354, 138);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(44, 42);
            this.button21.TabIndex = 28;
            this.button21.Tag = "9";
            this.button21.Text = "9";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.White;
            this.button20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button20.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.DimGray;
            this.button20.Location = new System.Drawing.Point(225, 138);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(37, 42);
            this.button20.TabIndex = 27;
            this.button20.Tag = "6";
            this.button20.Text = "6";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.White;
            this.button19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button19.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.DimGray;
            this.button19.Location = new System.Drawing.Point(96, 138);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(37, 42);
            this.button19.TabIndex = 26;
            this.button19.Tag = "3";
            this.button19.Text = "3";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.White;
            this.button18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button18.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.DimGray;
            this.button18.Location = new System.Drawing.Point(268, 138);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(37, 42);
            this.button18.TabIndex = 25;
            this.button18.Tag = "7";
            this.button18.Text = "7";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.White;
            this.button17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button17.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.DimGray;
            this.button17.Location = new System.Drawing.Point(311, 48);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(37, 39);
            this.button17.TabIndex = 24;
            this.button17.Tag = "Q";
            this.button17.Text = "Q";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.White;
            this.button16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button16.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.DimGray;
            this.button16.Location = new System.Drawing.Point(268, 48);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(37, 39);
            this.button16.TabIndex = 23;
            this.button16.Tag = "P";
            this.button16.Text = "P";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.White;
            this.button15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button15.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.DimGray;
            this.button15.Location = new System.Drawing.Point(225, 48);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(37, 39);
            this.button15.TabIndex = 22;
            this.button15.Tag = "O";
            this.button15.Text = "O";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.DimGray;
            this.button14.Location = new System.Drawing.Point(182, 48);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(37, 39);
            this.button14.TabIndex = 21;
            this.button14.Tag = "N";
            this.button14.Text = "N";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button13.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.DimGray;
            this.button13.Location = new System.Drawing.Point(139, 48);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(37, 39);
            this.button13.TabIndex = 20;
            this.button13.Tag = "M";
            this.button13.Text = "M";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button12.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.DimGray;
            this.button12.Location = new System.Drawing.Point(96, 48);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(37, 39);
            this.button12.TabIndex = 19;
            this.button12.Tag = "L";
            this.button12.Text = "L";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.DimGray;
            this.button11.Location = new System.Drawing.Point(53, 48);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(37, 39);
            this.button11.TabIndex = 18;
            this.button11.Tag = "K";
            this.button11.Text = "K";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.DimGray;
            this.button10.Location = new System.Drawing.Point(3, 48);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(44, 39);
            this.button10.TabIndex = 17;
            this.button10.Tag = "J";
            this.button10.Text = "J";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.DimGray;
            this.button9.Location = new System.Drawing.Point(354, 3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(44, 39);
            this.button9.TabIndex = 16;
            this.button9.Tag = "I";
            this.button9.Text = "I";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.DimGray;
            this.button8.Location = new System.Drawing.Point(311, 3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(37, 39);
            this.button8.TabIndex = 15;
            this.button8.Tag = "H";
            this.button8.Text = "H";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.DimGray;
            this.button7.Location = new System.Drawing.Point(268, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(37, 39);
            this.button7.TabIndex = 14;
            this.button7.Tag = "G";
            this.button7.Text = "G";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.DimGray;
            this.button6.Location = new System.Drawing.Point(225, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(37, 39);
            this.button6.TabIndex = 13;
            this.button6.Tag = "F";
            this.button6.Text = "F";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.DimGray;
            this.button5.Location = new System.Drawing.Point(182, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(37, 39);
            this.button5.TabIndex = 12;
            this.button5.Tag = "E";
            this.button5.Text = "E";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.DimGray;
            this.button4.Location = new System.Drawing.Point(139, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(37, 39);
            this.button4.TabIndex = 11;
            this.button4.Tag = "D";
            this.button4.Text = "D";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DimGray;
            this.button3.Location = new System.Drawing.Point(96, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(37, 39);
            this.button3.TabIndex = 10;
            this.button3.Tag = "C";
            this.button3.Text = "C";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.DimGray;
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(44, 39);
            this.button2.TabIndex = 9;
            this.button2.Tag = "A";
            this.button2.Text = "A";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.DimGray;
            this.button1.Location = new System.Drawing.Point(53, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(37, 39);
            this.button1.TabIndex = 8;
            this.button1.Tag = "B";
            this.button1.Text = "B";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.buttonCaractere);
            // 
            // picImagePendu
            // 
            this.picImagePendu.BackgroundImage = global::HangmanGame.Properties.Resources._1_Pendu;
            this.picImagePendu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picImagePendu.Location = new System.Drawing.Point(138, 66);
            this.picImagePendu.Name = "picImagePendu";
            this.picImagePendu.Size = new System.Drawing.Size(193, 220);
            this.picImagePendu.TabIndex = 0;
            this.picImagePendu.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "TIME : ";
            // 
            // point
            // 
            this.point.AutoSize = true;
            this.point.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.point.ForeColor = System.Drawing.Color.Gold;
            this.point.Location = new System.Drawing.Point(194, 11);
            this.point.Name = "point";
            this.point.Size = new System.Drawing.Size(63, 23);
            this.point.TabIndex = 2;
            this.point.Text = "PNTS :";
            // 
            // lblPoint
            // 
            this.lblPoint.AutoSize = true;
            this.lblPoint.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPoint.ForeColor = System.Drawing.Color.Gold;
            this.lblPoint.Location = new System.Drawing.Point(263, 11);
            this.lblPoint.Name = "lblPoint";
            this.lblPoint.Size = new System.Drawing.Size(20, 24);
            this.lblPoint.TabIndex = 3;
            this.lblPoint.Text = "0";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.White;
            this.lblTime.Location = new System.Drawing.Point(83, 9);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(50, 24);
            this.lblTime.TabIndex = 4;
            this.lblTime.Text = "0257";
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(150)))), ((int)(((byte)(90)))));
            this.panel.Controls.Add(this.lblGames);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.lblIndice);
            this.panel.Controls.Add(this.nomIndice);
            this.panel.Controls.Add(this.lblTime);
            this.panel.Controls.Add(this.lblPoint);
            this.panel.Controls.Add(this.point);
            this.panel.Controls.Add(this.label1);
            this.panel.Controls.Add(this.picImagePendu);
            this.panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(469, 408);
            this.panel.TabIndex = 0;
            // 
            // lblGames
            // 
            this.lblGames.AutoSize = true;
            this.lblGames.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGames.ForeColor = System.Drawing.Color.White;
            this.lblGames.Location = new System.Drawing.Point(407, 11);
            this.lblGames.Name = "lblGames";
            this.lblGames.Size = new System.Drawing.Size(20, 24);
            this.lblGames.TabIndex = 8;
            this.lblGames.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(333, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "Games : ";
            // 
            // lblIndice
            // 
            this.lblIndice.AutoSize = true;
            this.lblIndice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndice.ForeColor = System.Drawing.Color.White;
            this.lblIndice.Location = new System.Drawing.Point(217, 299);
            this.lblIndice.Name = "lblIndice";
            this.lblIndice.Size = new System.Drawing.Size(0, 28);
            this.lblIndice.TabIndex = 6;
            // 
            // nomIndice
            // 
            this.nomIndice.AutoSize = true;
            this.nomIndice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nomIndice.ForeColor = System.Drawing.Color.White;
            this.nomIndice.Location = new System.Drawing.Point(149, 299);
            this.nomIndice.Name = "nomIndice";
            this.nomIndice.Size = new System.Drawing.Size(73, 28);
            this.nomIndice.TabIndex = 5;
            this.nomIndice.Text = "Indice :";
            this.nomIndice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frm_ZoneJeu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 683);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frm_ZoneJeu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.btnRetour)).EndInit();
            this.panel2.ResumeLayout(false);
            this.table.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picImagePendu)).EndInit();
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox btnRetour;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel table;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.PictureBox picImagePendu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label point;
        private System.Windows.Forms.Label lblPoint;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblIndice;
        private System.Windows.Forms.Label nomIndice;
        private System.Windows.Forms.Label lblGames;
        private System.Windows.Forms.Label label2;
    }
}