﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HangmanGame
{
    public partial class frm_ZoneJeu : Form
    {
        List<String> listeMotsATrouver;
        List<String> listeIndice;
        List<Label> labelName;
        List<Image> imageHangman;
        Random random;
        String motChoisi;
        int countWin;
        int countImage;
        int countTime;

        public frm_ZoneJeu(List<String> listeMotsATrouver, List<String> listeIndice)
        {
            InitializeComponent();
            this.listeMotsATrouver = new List<String>();
            this.listeIndice = new List<String>();
            labelName = new List<Label>();
            imageHangman = new List<Image>()
            {
                Properties.Resources._1_Pendu,
                Properties.Resources._2_Pendu,
                Properties.Resources._3_Pendu,
                Properties.Resources._4_Pendu,
                Properties.Resources._5_Pendu,
                Properties.Resources._6_Pendu,
                Properties.Resources._7_Pendu,
                Properties.Resources._8_Pendu,
                Properties.Resources.perdu
            };
            random = new Random();
            countWin = 0;
            countImage = 0;
            countTime = 0;

            this.listeMotsATrouver = listeMotsATrouver;
            this.listeIndice = listeIndice;

            initialise();
        }

        private void initialise()
        {
            countImage = 0;
            countWin = 0;
            countTime = 0;
            picImagePendu.BackgroundImage = imageHangman[countImage];
            foreach (Button ctrl in table.Controls)
            {
                ctrl.BackColor = Color.White;
                ctrl.ForeColor = Color.DimGray;
            }

            timer1.Start();

            deleteLabel();
            motChoisi = motSelectionner(listeMotsATrouver);
            instantationLabel(motChoisi.Length);
            lblIndice.Text = listeIndice[listeMotsATrouver.IndexOf(motChoisi)];
        }

        private String motSelectionner(List<String> listeMotsATrouver)
        {
            return listeMotsATrouver[random.Next(0, listeMotsATrouver.Count)];
        }

        private void createLabel(int largeur, int hauteur)
        {
            Label lbl = new Label();
            lbl.Text = "_";
            lbl.Location = new Point(largeur, hauteur);
            lbl.Size = new Size(39, 41);
            lbl.Font = new Font("Segoe UI", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            lbl.ForeColor = Color.White;
            labelName.Add(lbl);
            panel.Controls.Add(lbl);
        }

        private void deleteLabel()
        {
            foreach (Label lbl in labelName)
            {
                panel.Controls.Remove(lbl);
            }
            labelName.Clear();
        }
        private void instantationLabel(int nbreLettre)
        {
            int nombrePairImpair = 0;
            int hauteur = 323;

            if (nbreLettre % 2 == 1)
            {
                nombrePairImpair = 1;
            }
            int largeur = panel.Width / 2 - (((nbreLettre / 2)+ nombrePairImpair) * 45);
            
            for (int i = 0; i < this.motChoisi.Length; i++)
            {
                largeur += 40;
                createLabel(largeur, hauteur);
            }
        }

        private void buttonCaractere(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            Char tagBtn = Convert.ToChar(button.Tag);
            bool trouver = verifierBtnCaractere(Char.ToLower(tagBtn), ref button, ref countWin);
            if (!trouver)
            {
                countImage++;
                button.BackColor = Color.Red;
                picImagePendu.BackgroundImage = imageHangman[countImage];
            }
            verifierGagnant(countImage, ref countWin);

        }

        private bool verifierBtnCaractere(Char caractere, ref Button button, ref int count)
        {
            bool trouver = false;
            for (int i = 0; i < this.motChoisi.Length; i++)
            {
                if (caractere.Equals(motChoisi[i]))
                {
                    labelName[i].Text = caractere.ToString();
                    button.BackColor = Color.Gold;
                    button.ForeColor = Color.White;
                    trouver = true;
                    count++;
                }
            }
            return trouver;
        }

        private void verifierGagnant(int compteur, ref int compteurGagnant)
        {
            if (compteurGagnant == this.motChoisi.Length)
            {
                rejouer("Vous avez gagné, Bien joué!!", "Gagné");
                lblPoint.Text = (int.Parse(lblPoint.Text)+100).ToString();
            }
            if (compteur >= imageHangman.Count - 1)
            {
                rejouer("Vous avez perdu, Dommage!!", "Perdu");
            }
        }

        private void rejouer(String phrase, String titre)
        {
            timer1.Stop();
            DialogResult message = MessageBox.Show(phrase, titre, MessageBoxButtons.YesNo);
            if (message == DialogResult.Yes)
            {
                initialise();
            }
            else if (message == DialogResult.No)
            {
                this.Close();
            }
            lblGames.Text = (int.Parse(lblGames.Text) + 1).ToString();
        }
        private void btnRetour_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            countTime++;
            lblTime.Text = countTime.ToString();

            if(countTime == 200)
            {
                rejouer("Le temps est écoulé, Dommage!!", "Perdu");
            }
        }

    }
}
